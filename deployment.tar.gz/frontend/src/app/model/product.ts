export interface Product
{
  id?: number;
  name: string;
  description: string;
  price: number;
  quantity: number;
  rating?: number;
}
